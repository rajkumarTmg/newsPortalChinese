import { SET_UPDATING } from '../types';

export default payload => ({
    type: SET_UPDATING,
    payload
});
