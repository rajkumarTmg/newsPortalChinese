import { SET_ADMIN } from '../types';

export default payload => ({
    type: SET_ADMIN,
    payload
});
