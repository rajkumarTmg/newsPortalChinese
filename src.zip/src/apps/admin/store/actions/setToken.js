import { SET_TOKEN } from '../types';

export default payload => ({
    type: SET_TOKEN,
    payload
});
