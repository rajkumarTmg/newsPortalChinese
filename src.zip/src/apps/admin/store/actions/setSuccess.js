import { SET_SUCCESS } from '../types';

export default payload => ({
    type: SET_SUCCESS,
    payload
});
