import { SET_ERROR } from '../types';

export default payload => ({
    type: SET_ERROR,
    payload
});
