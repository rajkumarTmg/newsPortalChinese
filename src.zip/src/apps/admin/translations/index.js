import uk from './uk';
import ru from './ru';
import en from './en';

export default {
    uk,
    ru,
    en
};
