export const SET_AUTHENTICATED = 'SET_AUTHENTICATED';
export const SET_ADMIN = 'SET_ADMIN';
export const SET_TOKEN = 'SET_TOKEN';
export const SET_UPDATING = 'SET_UPDATING';
export const SET_ERROR = 'SET_ERROR';
export const SET_SUCCESS = 'SET_SUCCESS';
