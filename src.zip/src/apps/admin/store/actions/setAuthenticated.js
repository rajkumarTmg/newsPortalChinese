import { SET_AUTHENTICATED } from '../types';

export default payload => ({
    type: SET_AUTHENTICATED,
    payload
});
